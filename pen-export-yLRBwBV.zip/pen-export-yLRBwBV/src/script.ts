import pygame
import math

# Initialize Pygame
pygame.init()

# Set up the window
size = (800, 600)
screen = pygame.display.set_mode(size)
pygame.display.set_caption("Camera Lens")

# Set up colors
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
RED = (255, 0, 0)

# Set up variables for the lens
focal_length = 200
aperture = 50
object_distance = 500

# Set up variables for the object
object_size = 50
object_height = 200
object_width = object_size

# Define function to calculate image distance
def calculate_image_distance():
    return ((1/focal_length) - (1/object_distance))**(-1)

# Define function to calculate image size
def calculate_image_size():
    image_distance = calculate_image_distance()
    return (object_size * image_distance) / object_distance

# Define function to draw the lens
def draw_lens():
    center_x = size[0]//2
    center_y = size[1]//2
    lens_radius = aperture * 2
    pygame.draw.circle(screen, BLACK, (center_x, center_y), lens_radius, 2)
    pygame.draw.circle(screen, RED, (center_x, center_y), aperture, 0)
    pygame.draw.line(screen, BLACK, (center_x, center_y - lens_radius), (center_x, center_y + lens_radius), 2)

# Define function to draw the object
def draw_object():
    center_x = size[0]//2
    center_y = size[1]//2 - object_height//2
    pygame.draw.rect(screen, WHITE, (center_x - object_width//2, center_y, object_width, object_height), 2)

# Define function to draw the image
def draw_image():
    image_distance = calculate_image_distance()
    image_size = calculate_image_size()
    image_x = size[0]//2
    image_y = size[1]//2 + int(image_distance)
    pygame.draw.rect(screen, WHITE, (image_x - int(image_size)//2, image_y - int(image_size)//2, int(image_size), int(image_size)), 2)

# Set up the main loop
done = False
clock = pygame.time.Clock()

while not done:
    # Handle events
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            done = True

    # Clear the screen
    screen.fill(WHITE)

    # Draw the lens, object, and image
    draw_lens()
    draw_object()
    draw_image()

    # Update the screen
    pygame.display.flip()

    # Limit the frame rate
    clock.tick(60)

# Quit Pygame
pygame.quit()
